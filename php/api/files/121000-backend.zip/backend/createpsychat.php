<?php
include('../conn.php');

$psy_profileid = $_POST['psy_profileid'];
$profile_id = $_POST['profile_id'];
$message = $_POST['message'];
$sender = $_POST['sender'];
$date = $_POST['date'];


$response = array();

try{

        $sql = "INSERT INTO psy_chat (chat_id,psy_profileid,profile_id,message,sender,date) 
VALUES(NULL,:psy_profileid,:profile_id,:message,:sender,:date)";

$stmt = $conn->prepare($sql);
$stmt->execute(
    [
        ':psy_profileid'=>$psy_profileid,
        ':profile_id'=>$profile_id,
        ':message'=>$message, 
        ':date'=>$date,   
        ':sender'=>$sender,
    ]
);
array_push($response,array("status"=>"Psychologist Chat Created"));
    
}
catch(Exception $e){
    // echo "There was a problem" . $e->getMessage();
    array_push($response, array("status"=>"Error while creating Psychologist Chat". $e->getMessage()));
}
echo(json_encode($response));