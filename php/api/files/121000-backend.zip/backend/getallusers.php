<?php
header("Access-Control-Allow-Methods: GET");
include "../conn.php";
$psy_profileid = $_GET['psy_profileid'];
$response = array();
$query2 = "SELECT DISTINCT(profile_id) FROM psy_chat WHERE psy_profileid=$psy_profileid";
$emstmt = $conn->prepare($query2);
$emstmt->execute();
$row = $emstmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($row);
