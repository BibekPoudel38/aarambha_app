<?php
header("Access-Control-Allow-Methods: GET");
include "../conn.php";
$psy_profileid = $_GET['psy_profileid'];
$profile_id = $_GET['profile_id'];
$response = array();
$query2 = "SELECT * FROM psy_chat WHERE psy_profileid = $psy_profileid AND profile_id=$profile_id";
$emstmt = $conn->prepare($query2);
$emstmt->execute();
$row = $emstmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($row);
