<?php
header("Access-Control-Allow-Methods: GET");
include "../conn.php";
$chat_id = isset($_GET['chat_id']);
$response = array();
if($chat_id != NULL){
    $query1 = "DELETE from psy_chat WHERE id=$chat_id";
    $emstmt = $conn->prepare($query1);
    $emstmt->execute();
    
}
else{
    $query2 = "DELETE FROM psy_chat";
    $emstmt = $conn->prepare($query2);
    $emstmt->execute();
    
}